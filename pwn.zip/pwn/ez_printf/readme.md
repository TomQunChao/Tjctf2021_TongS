printf漏洞

name:ez_printf
description:简单格式化漏洞