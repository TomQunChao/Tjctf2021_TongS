堆利用--修改fd的低位（来源于某本书）

name:ez_heap

description: 来源于某本书上，刚弄懂的例子（逃）